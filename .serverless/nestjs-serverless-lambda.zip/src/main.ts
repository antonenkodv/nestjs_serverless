import { ValidationPipe } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import cookieParser from 'cookie-parser';
import { AppModule } from './app.module';

async function bootstrap() {  console.log('here1')
  try{
    const app = await NestFactory.create(AppModule);
    console.log('here2')
    app.useGlobalPipes(new ValidationPipe());
    app.use(cookieParser());
    await app.listen(3000);
    console.log('here')
  }catch (e){
  console.log(e)
  }

}
bootstrap();
